import org.bson.Document;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;		
import com.mongodb.client.MongoDatabase; 
import com.mongodb.MongoClient; 
import com.mongodb.MongoCredential;
import com.mongodb.client.MongoClients;

public class JavaMongoExample {
    private final MongoClient mongoClient;
    private final MongoDatabase database;
    private final MongoCollection<Document> collection;
    
     public JavaMongoExample() {
        mongoClient = (MongoClient) MongoClients.create("mongodb+srv://ayaashraf:<password>@cluster0.yzc5vmh.mongodb.net/?retryWrites=true&w=majority");
        database = mongoClient.getDatabase("ITI");
        collection = database.getCollection("Products");  
        
}
   public static void main( String args[] ) {  
     JavaMongoExample mongo = new JavaMongoExample();
             

//      // Creating a Mongo client 
//      MongoClient mongo = new MongoClient( "localhost" , 27017 ); 
//   
//      // Creating Credentials 
//      MongoCredential credential; 
//      credential = MongoCredential.createCredential("sampleUser", "myDb", 
//         "password".toCharArray()); 
//      System.out.println("Connected to the database successfully");  
//      
//      // Accessing the database 
//      MongoDatabase database = mongo.getDatabase("myDb"); 
//      System.out.println("Credentials ::"+ credential);     
   } 
}

