/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.iti;
import com.mongodb.client.MongoDatabase;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import org.bson.Document;
/**
 *
 * @author eng_aya
 */
public class ProductConn {

   public static void main( String args[] ) {
      // Creating a Mongo client
     MongoClientURI uri = new MongoClientURI("mongodb+srv://ayaashraf:iti*2022@cluster0.yzc5vmh.mongodb.net/?retryWrites=true&w=majority");
     MongoClient mongo = new MongoClient(uri);
     System.out.println("Connected to the database successfully");
      //Accessing the database
      MongoDatabase database = mongo.getDatabase("ITI3");
      //Creating a collection
//      database.createCollection("products");
      MongoCollection<Document> collection = database.getCollection("products");
      Document document = new Document();
      document.put("name", "product 1");
      document.put("price", 2000);
      collection.insertOne(document);
      System.out.println("Collection created successfully");
   }
   } 
   




